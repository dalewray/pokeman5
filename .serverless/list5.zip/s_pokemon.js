
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'dalewray',
  applicationName: 'pokemon',
  appUid: 'PYJnCFybgNfxJ9hjbz',
  orgUid: '4655e772-4708-463c-a658-dca0820f6519',
  deploymentUid: '19b2b213-adce-4037-86e9-daee8a6e539a',
  serviceName: 'list5',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'list5-dev-pokemon', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.pokemon, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}