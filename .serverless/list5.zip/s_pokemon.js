
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'dalewray',
  applicationName: 'pokemon',
  appUid: 'PYJnCFybgNfxJ9hjbz',
  orgUid: '4655e772-4708-463c-a658-dca0820f6519',
  deploymentUid: '032245b0-21c9-4409-b8b8-f15326fbf586',
  serviceName: 'list5',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'list5-dev-pokemon', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.pokemon, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}